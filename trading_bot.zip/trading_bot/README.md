# Binance Futures Testnet Trading Bot

## Setup

Install dependencies

pip install -r requirements.txt

Add API keys in `.env`

API_KEY=your_api_key
API_SECRET=your_secret_key

## Run Market Order

python cli.py --symbol BTCUSDT --side BUY --type MARKET --quantity 0.002

## Run Limit Order

python cli.py --symbol BTCUSDT --side SELL --type LIMIT --quantity 0.002 --price 68000
