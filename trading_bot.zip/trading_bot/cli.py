import argparse
from bot.orders import place_order
from bot.validators import validate_side, validate_type
from bot.logging_config import setup_logging


def main():

    setup_logging()

    parser = argparse.ArgumentParser(description="Binance Futures Testnet Trading Bot")

    parser.add_argument("--symbol", required=True, help="Trading pair (e.g. BTCUSDT)")
    parser.add_argument("--side", required=True, help="BUY or SELL")
    parser.add_argument("--type", required=True, help="MARKET or LIMIT")
    parser.add_argument("--quantity", type=float, required=True, help="Order quantity")
    parser.add_argument("--price", type=float, help="Price required for LIMIT orders")

    args = parser.parse_args()

    # Validate inputs
    validate_side(args.side)
    validate_type(args.type)

    print("\nOrder Request")
    print("Symbol:", args.symbol)
    print("Side:", args.side)
    print("Type:", args.type)
    print("Quantity:", args.quantity)

    if args.type == "LIMIT":
        print("Price:", args.price)

    try:

        order = place_order(
            args.symbol,
            args.side,
            args.type,
            args.quantity,
            args.price
        )

        print("\nOrder Response:")
        print(order)

        if "orderId" in order:
            print("\nOrder Details")
            print("Order ID:", order["orderId"])
            print("Status:", order["status"])
            print("Executed Quantity:", order["executedQty"])

            if "avgPrice" in order:
                print("Average Price:", order["avgPrice"])

            print("\n✅ Order placed successfully!")

        else:
            print("\n❌ Order failed. Check response above.")

    except Exception as e:
        print("\n❌ Error placing order:", str(e))


if __name__ == "__main__":
    main()